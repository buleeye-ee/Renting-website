package com.livegoods.order.service;

import com.livegoods.commons.pojo.Order;

import java.util.List;

public interface OrderService {

    //查询用户的订单集合
    List<Order> getOrders(String user);
}
