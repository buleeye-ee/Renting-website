module.exports = {
    hasMore: true,
    data: [
        {
            id: Math.random().toString().slice(2),
            title: "豪宅 · 使馆壹号院4居室-南",
            houseType: "17/19层| 4室1厅 - 273.97 ㎡",
            price: "<h3>130000</h3>",
            rentType: "整租",
            img: "http://iwenwiki.com/api/livable/search/1.jpg"
        },
        {
            id: Math.random().toString().slice(2),
            title: "豪宅 · 金茂府东区3居室-南北",
            houseType: "201.27 ㎡| 15/24层| 3室1厅",
            price: "<h3>40000</h3>",
            rentType: "整租",
            img: "http://iwenwiki.com/api/livable/search/2.JPG"
        },
        {
            id: Math.random().toString().slice(2),
            title: "豪宅 · 使馆壹号院2居室-南",
            houseType: "204 ㎡| 2/19层| 2室1厅",
            price: "<h3>42000</h3>",
            rentType: "整租",
            img: "http://iwenwiki.com/api/livable/search/3.jpg"
        },
        {
            id: Math.random().toString().slice(2),
            title: "豪宅 · 使馆壹号院3居室-南",
            houseType: "237 ㎡| 13/19层| 3室1厅",
            price: "<h3>80000</h3>",
            rentType: "整租",
            img: "http://iwenwiki.com/api/livable/search/4.JPG"
        },
        {
            id: Math.random().toString().slice(2),
            title: "豪宅 · 棕榈泉国际公寓2居室-南北",
            houseType: "176.52 ㎡| 2/30层| 2室1厅",
            price: "<h3>33000</h3>",
            rentType: "整租",
            img: "http://iwenwiki.com/api/livable/search/5.jpg"
        },
        {
            id: Math.random().toString().slice(2),
            title: "豪宅 · 华悦国际公寓6居室-南",
            houseType: "235.76 ㎡| 7/24层| 3室2厅",
            price: "<h3>50000</h3>",
            rentType: "整租",
            img: "http://iwenwiki.com/api/livable/search/6.jpg"
        }
    ]

}
