package com.livegoods.login.service.impl;

import com.livegoods.commons.pojo.LoginLog;
import com.livegoods.commons.pojo.ValidateCode;
import com.livegoods.commons.vo.LivegoodsResult;
import com.livegoods.login.dao.LoginLogDao;
import com.livegoods.login.dao.ValidateCodeDao;
import com.livegoods.login.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Random;

@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    private ValidateCodeDao validateCodeDao;

    @Autowired
    private LoginLogDao loginLogDao;

    /**
     * 生成验证码
     * @param phone
     * @return
     */
    @Override
    public LivegoodsResult sendyzm(String phone) {
        //查找phone对应的验证码
        ValidateCode validateCode = validateCodeDao.get(phone);
        if(validateCode != null){
            return LivegoodsResult.error("验证码仍在有效期内，不要重复申请");
        }

        StringBuilder builder = new StringBuilder("");
        Random r = new Random();
        for (int i = 0; i < 4; i++) {
            builder.append(r.nextInt(10));
        }

        //生成验证码
        String validateCode_1 = builder.toString();
        //创建验证码对象
        ValidateCode code = new ValidateCode();
        code.setPhone(phone);
        code.setValidateCode(validateCode_1);

        //保存到redis中
        validateCodeDao.set(code.getPhone(),code);

        //返回结果
        LivegoodsResult result = LivegoodsResult.ok();
        result.setMsg("验证码发送成功");
        System.out.println("手机号：" + phone + "，验证码, " + validateCode_1);

        return result;
    }

    /**
     * 登录
     * @param username
     * @param password
     * @return
     */
    @Override
    public LivegoodsResult login(String username, String password) {
        //1 创建登录日志对象
        LoginLog loginLog = new LoginLog();
        loginLog.setUsername(username);
        loginLog.setLoginTime(new Date());
        loginLog.setType("1");  //1-验证码登录

        //2 从redis中查询对应用户的验证码
        ValidateCode validateCode = validateCodeDao.get(username);

        //2.1 判断验证码是否为空
        if(validateCode == null){
            loginLog.setSuccess(false);
            loginLog.setMessage("验证码已过期");
            loginLogDao.insertLoginLog(loginLog);
            return LivegoodsResult.error("用户名或验证码错误，或验证码已过期");
        }

        //2.2 判断验证码与redis中存储的是否一致
        if(!password.equals(validateCode.getValidateCode())){
            loginLog.setSuccess(false);
            loginLog.setMessage("验证码不匹配");
            loginLogDao.insertLoginLog(loginLog);
            return LivegoodsResult.error("用户名或验证码错误，或验证码已过期");
        }

        //3 保存日志
        loginLog.setSuccess(true);
        loginLog.setMessage("登录成功");
        loginLogDao.insertLoginLog(loginLog);
        //4 从redis中删除验证码
        validateCodeDao.delete(username);

        //5 返回livegoodsresult，提示登录成功
        return LivegoodsResult.ok("登录成功");
    }

}
