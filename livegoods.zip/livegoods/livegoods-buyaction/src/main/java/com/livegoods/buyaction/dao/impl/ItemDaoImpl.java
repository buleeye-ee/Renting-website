package com.livegoods.buyaction.dao.impl;

import com.livegoods.buyaction.dao.ItemDao;
import com.livegoods.commons.pojo.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ItemDaoImpl implements ItemDao {

    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public Item get(String key) {
        Item item = (Item) redisTemplate.opsForValue().get(key);
        return item;
    }
}
