package com.livegoods.detail.controller;

import com.livegoods.commons.pojo.Item;
import com.livegoods.commons.pojo.Order;
import com.livegoods.commons.vo.LivegoodsResult;
import com.livegoods.detail.service.DetailService;
import com.livegoods.detail.service.OrderServiceFeignClient;
import io.vavr.control.Try;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
public class DetailController {

    @Autowired
    private DetailService detailService;

    @Autowired(required = false)
    private OrderServiceFeignClient orderServiceFeignClient;

    /**
     * 根据商品id查询商品详情
     * @param id
     * @return
     */
    @GetMapping("/details")
    public Item findDetails(String id){
        Item item = detailService.getDetails(id);
        return item;
    }

    /**
     * 远程调用订单查询方法
     * @param user
     * @return
     */
    @GetMapping("/detail/order")
    public List<Order> selectOrder(String user){
        return orderServiceFeignClient.getOrders(user);
    }

    @GetMapping("/testDetails")
    public LivegoodsResult testDetails(){
        ArrayList<String> idList = new ArrayList<>();
        idList.add("628ca685fefa3f45504692d6");
        idList.add("628ca685fefa3f45504692d5");
        idList.add("628ca685fefa3f45504692d4");
        idList.add("628ca685fefa3f45504692d3");

        for (String s : idList) {
            Item item = detailService.getDetails(s);
        }
        return LivegoodsResult.ok();
    }
}
