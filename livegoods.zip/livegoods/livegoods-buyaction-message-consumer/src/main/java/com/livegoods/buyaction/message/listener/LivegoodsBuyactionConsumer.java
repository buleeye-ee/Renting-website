package com.livegoods.buyaction.message.listener;

import com.livegoods.buyaction.message.service.BuyactionService;
import com.livegoods.commons.message.LivegoodsBuyMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.function.Consumer;

@Component
@Slf4j
public class LivegoodsBuyactionConsumer {

    @Autowired
    private BuyactionService buyactionService;

    @Bean
    public Consumer<LivegoodsBuyMessage> livegoodsMessenger(){
        return message -> {
            //商品主键
            String itemId = message.getItemId();
            String username = message.getUsername();
            boolean result = buyactionService.buyaction(itemId,username);
            log.info("消息消费结果.........." + result);
        };
    }
}
