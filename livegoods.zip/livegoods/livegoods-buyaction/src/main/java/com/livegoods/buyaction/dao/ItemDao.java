package com.livegoods.buyaction.dao;

import com.livegoods.commons.pojo.Item;

public interface ItemDao {

    //根据商品key值到redis查询商品详情
    Item get(String key);
}
