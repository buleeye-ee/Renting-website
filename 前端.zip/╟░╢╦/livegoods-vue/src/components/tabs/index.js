import Tabs from "./tabs"
import Tab from "./tab"

export default (Vue) => {
    Vue.component(Tabs.name,Tabs);
    Vue.component(Tab.name,Tab);
}