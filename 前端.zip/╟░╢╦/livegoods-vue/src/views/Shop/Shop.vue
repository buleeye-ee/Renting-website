<template>
    <div>
        shop
        <FootNav />
    </div>
</template>
<script>
import FootNav from '../../components/FootNav/FootNav'
export default {
    name:'Shop',
    data(){
        return{}
    },
    components:{
        FootNav
    }
}
</script>