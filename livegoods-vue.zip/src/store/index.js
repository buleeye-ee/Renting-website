import Vue from 'vue'
import Vuex from 'vuex'

import userInfo from "./user.js"



// 引入vuex持久化插件
import createPersistedState from "vuex-persistedstate";
Vue.use(Vuex)


export default new Vuex.Store({
    state: {
        curcity: '北京',
        searchMsg: '',
        collect: [],
        user:''
    },
    mutations: {
        setCity(state, payload) {
            state.curcity = payload.data
        },
        setSearchMsg(state, payload) {
            state.searchMsg = payload.data
        },
        addCollect(state, payload) {
            state.collect.push(payload.data)
            state.collect = [...state.collect]
        },
        delCollect(state, payload) {
            let index = state.collect.indexOf(payload.data)
            if (index > -1) {
                state.collect.splice(index, 1)
            }
            state.collect = [...state.collect]
        },
        setUser(state,payload){
            state.user = payload.data
        }
    },
    actions: {
        setCityAciton(context, payload) {
            context.commit('setCity', payload)
        },
        setSearchMsgAciton(context, payload) {
            context.commit('setSearchMsg', payload)
        },
        addCollectAciton(context, payload) {
            context.commit('addCollect', payload)
        },
        delCollectAction(context, payload) {
            context.commit('delCollect', payload)
        },
        setUserAction(context,payload){
            context.commit('setUser',payload)
        }
    },
    modules: {
        userInfo
    },
     /* vuex数据持久化配置 */
  plugins: [
    createPersistedState({
      // 存储方式：localStorage、sessionStorage、cookies
      storage: window.sessionStorage,
      // 存储的 key 的key值
      key: "store",
      render(state) {
        // 要存储的数据：本项目采用es6扩展运算符的方式存储了state中所有的数据
        return { ...state };
      }
    })
  ]

})
