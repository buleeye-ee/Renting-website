package com.livegoods.buyaction.message.dao.impl;

import com.livegoods.buyaction.message.dao.ItemDao;
import com.livegoods.commons.pojo.Item;
import com.mongodb.client.result.UpdateResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

@Repository
public class ItemDaoImpl implements ItemDao {

    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * 更新商品数据，是否已出租
     * @param id
     * @param rented
     * @return
     */
    @Override
    public long update(String id, Boolean rented) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));     //创建查询对象
        Update update = Update.update("isRented", rented);  //设置更新条件
        UpdateResult result = mongoTemplate.updateFirst(query, update, Item.class); //执行更新
        return result.getModifiedCount();
    }
}
