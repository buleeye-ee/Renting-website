package com.livegoods.search.service.impl;

import com.livegoods.commons.vo.LivegoodsResult;
import com.livegoods.search.dao.ItemDao4ES;
import com.livegoods.search.pojo.Item4ES;
import com.livegoods.search.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SearchServiceImpl implements SearchService {

    @Autowired
    private ItemDao4ES itemDao4ES;

    /**
     * 搜索商品
     * @param city
     * @param content
     * @param page
     * @param rows
     * @return
     */
    @Override
    public LivegoodsResult search(String city, String content, int page, int rows) {
        List<Item4ES> item4ESList = itemDao4ES.queryForPage(city, content, page, rows);
        LivegoodsResult livegoodsResult = LivegoodsResult.ok(item4ESList);
        return livegoodsResult;
    }
}
