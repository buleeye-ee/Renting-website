package com.livegoods.buyaction.message.service.impl;

import com.livegoods.buyaction.message.dao.ItemDao;
import com.livegoods.buyaction.message.dao.OrderDao;
import com.livegoods.buyaction.message.redisDao.ItemDao4Redis;
import com.livegoods.buyaction.message.service.BuyactionService;
import com.livegoods.commons.pojo.Item;
import com.livegoods.commons.pojo.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class BuyactionServiceImpl implements BuyactionService {

    @Autowired
    private ItemDao itemDao;

    @Autowired
    private ItemDao4Redis itemDao4Redis;

    @Autowired
    private OrderDao orderDao;

    @Value("${livegoods.cache.names.item.prefix}")
    private String itemPrefix;

    @Value("${livegoods.cache.names.item.suffix}")
    private String itemSuffix;

    /**
     * 预订商品并保存订单
     * @param id
     * @param user
     * @return
     */
    @Override
    public boolean buyaction(String id, String user) {
        //1 根据key到redis获取商品
        String key = itemPrefix + "::" + itemSuffix + "(" + id + ")";
        Item item = itemDao4Redis.get(key);
        //2 设置商品对象的isRented属性
        item.setIsRented(true);     //设置为已出租
        //3 更新商品数据到redis
        boolean isUpdateRedis = itemDao4Redis.set(key, item);
        //4 如果更新成功生成order订单数据
        if(isUpdateRedis){
            long rows = itemDao.update(id, true);
            if(rows == 1){
                //5 保存订单
                Order order = new Order();
                order.setCommentState(0);
                order.setHouseType(item.getHouseType4Search());
                order.setImg(item.getImg());
                order.setPrice(item.getPrice().toString());
                order.setRentType(item.getRentType());
                order.setTitle(item.getTitle());
                order.setUsername(user);

                orderDao.save(order);
                return true;
            }
        }
        return false;
    }
}
