package com.livegoods.login.dao;

import com.livegoods.commons.pojo.ValidateCode;

public interface ValidateCodeDao {

    //保存验证码到redis
    void set(String key,Object value);
    //根据手机号取出验证码
    ValidateCode get(String key);
    //删除验证码
    Boolean delete(String key);
}
