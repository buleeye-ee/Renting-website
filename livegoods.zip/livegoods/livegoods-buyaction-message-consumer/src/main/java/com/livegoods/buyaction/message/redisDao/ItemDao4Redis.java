package com.livegoods.buyaction.message.redisDao;

import com.livegoods.commons.pojo.Item;

public interface ItemDao4Redis {

    //根据key值查询缓存的商品
    Item get(String key);

    //设置商品键值对到redis，如果key重复覆盖
    boolean set(String key,Object value);
}
