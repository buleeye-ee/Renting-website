package com.livegoods.buytime.service;

import com.livegoods.buytime.dao.ItemDao;
import com.livegoods.commons.pojo.Item;
import com.livegoods.commons.vo.LivegoodsResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//根据商品id查询商品预订时间
@Service
public class BuytimeServiceImpl implements BuytimeService{

    @Autowired
    private ItemDao itemDao;

    @Override
    public LivegoodsResult getBuyTimeById(String id) {
        Item item = itemDao.findById(id);
        LivegoodsResult livegoodsResult = LivegoodsResult.ok();
        //获取商品预订时间戳
        livegoodsResult.setTime(item.getBuytime().getTime());
        return livegoodsResult;
    }
}
