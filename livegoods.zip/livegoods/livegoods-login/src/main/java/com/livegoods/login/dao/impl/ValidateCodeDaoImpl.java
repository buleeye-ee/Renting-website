package com.livegoods.login.dao.impl;

import com.livegoods.commons.pojo.ValidateCode;
import com.livegoods.login.dao.ValidateCodeDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import java.time.Duration;

@Repository
public class ValidateCodeDaoImpl implements ValidateCodeDao {

    @Autowired
    private RedisTemplate<String,Object> redisTemplate;

    /**
     * 保存key值到redis
     * @param key
     * @param value
     */
    @Override
    public void set(String key, Object value) {
        redisTemplate.opsForValue().set(key,value, Duration.ofMinutes(2L));
    }

    /**
     * 根据key获取value
     * @param key
     * @return
     */
    @Override
    public ValidateCode get(String key) {
        ValidateCode validateCode = (ValidateCode) redisTemplate.opsForValue().get(key);
        return validateCode;
    }

    /**
     * 删除key
     * @param key
     * @return
     */
    @Override
    public Boolean delete(String key) {
        return redisTemplate.delete(key);
    }
}
