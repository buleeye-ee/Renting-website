package com.livegoods.test;

import com.livegoods.commons.pojo.Item;
import com.livegoods.search.SearchApp;
import com.livegoods.search.dao.ItemDao4ES;
import com.livegoods.search.pojo.Item4ES;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest(classes = SearchApp.class)
@RunWith(SpringRunner.class)
public class TestSearch {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private ItemDao4ES itemDao4ES;

    @Value("${livegoods.banner.nginx.prefix}")
    private String nginxPrefix;

    @Test
    public void testInitES(){
        List<Item> itemList = mongoTemplate.findAll(Item.class);
        ArrayList<Item4ES> arrayList = new ArrayList<>();
        for (Item item : itemList) {
            Item4ES item4ES = new Item4ES();
            item4ES.setId(item.getId());
            item4ES.setTitle(item.getTitle());
            item4ES.setCity(item.getCity());
            item4ES.setHouseType(item.getHouseType());
            item4ES.setImg(nginxPrefix + item.getImg());
            item4ES.setPrice(String.valueOf(item.getPrice()));
            item4ES.setRentType(item.getRentType());
            arrayList.add(item4ES);
        }
        itemDao4ES.batchIndex(arrayList);
    }
}
