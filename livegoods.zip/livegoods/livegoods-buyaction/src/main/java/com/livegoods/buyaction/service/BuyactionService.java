package com.livegoods.buyaction.service;

import com.livegoods.commons.vo.LivegoodsResult;

public interface BuyactionService {

    /**
     * 预订商品服务方法
     * @param id
     * @param user
     * @return
     */
    LivegoodsResult buyaction(String id,String user);
}
