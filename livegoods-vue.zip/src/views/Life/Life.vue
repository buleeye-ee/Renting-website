<template>
    <div>
        lift
        <FootNav />
    </div>
</template>
<script>
import FootNav from '../../components/FootNav/FootNav'
export default {
    name:'Life',
    data(){
        return{}
    },
    components:{
        FootNav
    }
}
</script>