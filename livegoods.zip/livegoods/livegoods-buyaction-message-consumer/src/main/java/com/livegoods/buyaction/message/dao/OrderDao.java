package com.livegoods.buyaction.message.dao;

import com.livegoods.commons.pojo.Order;

public interface OrderDao {

    //保存订单数据
    void save(Order order);
}
