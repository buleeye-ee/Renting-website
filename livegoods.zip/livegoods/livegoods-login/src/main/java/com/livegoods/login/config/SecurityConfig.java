package com.livegoods.login.config;

import com.livegoods.login.service.MyAuthenticationService;
import com.livegoods.login.service.MyDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private MyAuthenticationService myAuthenticationService;

    @Autowired
    private MyDetailsService myDetailsService;

    /**
     * 身份安全管理器
     * @param auth
     * @throws Exception
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(myDetailsService);  //自定义登录逻辑类
//        super.configure(auth);
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        super.configure(web);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.formLogin()
                .loginProcessingUrl("/login")   //登录处理url
                .successForwardUrl("/details")  //登录成功后转发
                .successHandler(myAuthenticationService)    //登录成功后的处理器
                .failureHandler(myAuthenticationService)    //登录失败后的处理器
                .and().rememberMe()
                .tokenValiditySeconds(1209600)
                .and().authorizeRequests().antMatchers("/sendyzm").permitAll()
                .anyRequest().authenticated();

        http.csrf().disable();  //关闭crsf防护
        http.cors().configurationSource(corsConfigurationSource());   //允许跨域

//        super.configure(http);
    }

    /**
     * 跨域配置
     * @return
     */
    public CorsConfigurationSource corsConfigurationSource(){
        CorsConfiguration corsConfiguration = new CorsConfiguration();
        corsConfiguration.addAllowedOrigin("*");    //允许跨域的站点
        corsConfiguration.addAllowedMethod("*");    //允许跨域的方法
        corsConfiguration.addAllowedHeader("*");    //允许跨域的请求头

        //对所有的url生效
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**",corsConfiguration);
        return source;
    }

}
