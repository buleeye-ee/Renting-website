package com.livegoods.login.service;

import com.livegoods.commons.vo.LivegoodsResult;

public interface LoginService {

    //发送验证码
    LivegoodsResult sendyzm(String phone);

    //登录
    LivegoodsResult login(String username,String password);
}
