package com.livegoods.search.pojo;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@ToString
@Document(indexName = "livegoods-item")
public class Item4ES {

    @Id
    private String id;

    @Field(type= FieldType.Keyword)
    private String rentType;    //出租类型

    @Field(type= FieldType.Keyword)
    private String price;

    @Field(type= FieldType.Text,analyzer = "ik_max_word")
    private String houseType;   //房屋类型

    @Field(type= FieldType.Keyword)
    private String img;     //房屋图片

    @Field(type= FieldType.Text,analyzer = "ik_max_word")
    private String title;       //商品标题

    @Field(type= FieldType.Keyword)
    private String city;

}
