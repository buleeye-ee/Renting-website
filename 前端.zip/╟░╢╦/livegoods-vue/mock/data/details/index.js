module.exports = {
    imgs: [
        "http://iwenwiki.com/api/livable/details/1.jpg",
        "http://iwenwiki.com/api/livable/details/2.jpg",
        "http://iwenwiki.com/api/livable/details/3.jpg",
        "http://iwenwiki.com/api/livable/details/4.jpg",
        "http://iwenwiki.com/api/livable/details/5.jpg",
        "http://iwenwiki.com/api/livable/details/6.jpg",
        "http://iwenwiki.com/api/livable/details/7.jpg",
        "http://iwenwiki.com/api/livable/details/8.jpg",
        "http://iwenwiki.com/api/livable/details/9.jpg",
        "http://iwenwiki.com/api/livable/details/10.jpg",
        "http://iwenwiki.com/api/livable/details/11.jpg",
        "http://iwenwiki.com/api/livable/details/12.jpg",
        "http://iwenwiki.com/api/livable/details/13.jpg"
    ],
    title: "豪宅 · 使馆壹号院4居室-南",
    price: "130000",
    rentType: "整租",
    houseType: "273.97 ㎡",
    info: {
        years: "2002年",
        type: "4室1厅",
        level: "17/19层",
        style: "精装性",
        orientation: "朝南"
    }
}
