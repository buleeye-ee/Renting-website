package com.livegoods.buyaction.message.service;

public interface BuyactionService {

    //预订商品
    boolean buyaction(String id,String user);
}
