package com.livegoods.login.dao;

import com.livegoods.commons.pojo.LoginLog;

public interface LoginLogDao {

    //保存日志
    void insertLoginLog(LoginLog loginLog);
}
