package com.livegoods.login.service;

import com.livegoods.commons.pojo.ValidateCode;
import com.livegoods.login.dao.ValidateCodeDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class MyDetailsService implements UserDetailsService {

    @Autowired
    private ValidateCodeDao validateCodeDao;

    /**
     * 自定义登录逻辑
     * @param username
     * @return
     * @throws UsernameNotFoundException
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        ValidateCode validateCode = validateCodeDao.get(username);
        String password = "";

        if(validateCode == null){
            //do nothing
        }else{
            password = validateCode.getValidateCode();
        }
        //用户权限集合
        ArrayList<GrantedAuthority> authorities = new ArrayList<>();
        UserDetails userDetails = new User(username,"{noop}" + password,    //noop-不加密，bcrypt--加密
                true,   //启用用户
                true,   //用户永不过期
                true,   //凭证永不过期
                true,   //锁定用户
                authorities);

        return userDetails;
    }
}
