package com.livegoods.search.dao.impl;

import com.livegoods.search.dao.ItemDao4ES;
import com.livegoods.search.pojo.Item4ES;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.core.IndexOperations;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.query.IndexQuery;
import org.springframework.data.elasticsearch.core.query.IndexQueryBuilder;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.stereotype.Repository;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class ItemDao4ESImpl implements ItemDao4ES {

    @Autowired
    private ElasticsearchRestTemplate restTemplate;

    @Value("${livegoods.search.init.enabled}")
    private boolean initEnabled = false;

    /**
     * 批量添加数据到es
     * @param items
     */
    @Override
    public void batchIndex(List<Item4ES> items) {
        //判断是否需要初始化索引
        if(initEnabled){
            createIndex();
        }

        ArrayList<IndexQuery> list = new ArrayList<>();
        for (Item4ES item : items) {
            list.add(new IndexQueryBuilder().withObject(item).build());
        }
        //批量插入数据
        restTemplate.bulkIndex(list,Item4ES.class);
    }

    /**
     * 分页查询
     * @param city
     * @param content
     * @param page
     * @param rows
     * @return
     */
    @Override
    public List<Item4ES> queryForPage(String city, String content, int page, int rows) {
        //创建搜索条件集合
        BoolQueryBuilder shouldBuilder = QueryBuilders.boolQuery()
                .should(QueryBuilders.matchQuery("title",content))  //标题搜索
                .should(QueryBuilders.matchQuery("houseType",content))  //房屋类型
                .should(QueryBuilders.matchQuery("rentType",content));  //租赁类型

        //设置查询条件之间的关系
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        queryBuilder.must(QueryBuilders.matchQuery("city",city)).must(shouldBuilder);

        //创建搜索条件对象
        NativeSearchQuery query = new NativeSearchQueryBuilder()
                .withQuery(queryBuilder)
                .withPageable(PageRequest.of(page,rows))
                .build();
        //搜索
        SearchHits<Item4ES> resultPage = restTemplate.search(query,Item4ES.class);
        List<SearchHit<Item4ES>> searchHits = resultPage.getSearchHits();
        ArrayList<Item4ES> list = new ArrayList<>();
        for (SearchHit<Item4ES> searchHit : searchHits) {
            Item4ES item4ES = new Item4ES();
            //构建数据
            item4ES.setId(searchHit.getContent().getId());
            item4ES.setRentType(searchHit.getContent().getRentType());  //租赁类型
            item4ES.setPrice(searchHit.getContent().getPrice());     //价格
            item4ES.setImg(searchHit.getContent().getImg());        //图片
            item4ES.setHouseType(searchHit.getContent().getHouseType());    //房屋类型
            item4ES.setCity(searchHit.getContent().getCity());      //城市
            item4ES.setTitle(searchHit.getContent().getTitle());    //商品标题

            list.add(item4ES);
        }

        return list;
    }

    //创建索引
    private void createIndex() {
        IndexOperations indexOps = restTemplate.indexOps(Item4ES.class);
        if(indexOps.exists()){
            indexOps.delete();
        }else{
            indexOps.create();
            indexOps.refresh();
        }
    }
}
