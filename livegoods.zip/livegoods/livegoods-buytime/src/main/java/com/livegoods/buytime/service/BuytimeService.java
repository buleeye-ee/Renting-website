package com.livegoods.buytime.service;

import com.livegoods.commons.vo.LivegoodsResult;

public interface BuytimeService {

    //根据商品id查询商品预订时间
    LivegoodsResult getBuyTimeById(String id);
}
