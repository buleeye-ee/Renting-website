package com.livegoods.banner.service;

import com.livegoods.commons.vo.LivegoodsResult;

public interface BannerService {

    //轮播图查询
    LivegoodsResult getBanners();
}
