package com.livegoods.buyaction.message.dao;

public interface ItemDao {

    //更新商品数据，是否已出租
    long update(String id,Boolean rented);
}
