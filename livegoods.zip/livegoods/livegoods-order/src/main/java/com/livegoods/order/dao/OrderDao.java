package com.livegoods.order.dao;

import com.livegoods.commons.pojo.Order;

import java.util.List;

public interface OrderDao {

    //根据手机号查询名下的order数据
    List<Order> getOrders(String user);
}
